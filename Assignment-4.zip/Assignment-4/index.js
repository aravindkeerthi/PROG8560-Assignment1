// Assignment-4, Aravind Keerthi, Student ID - 8764757, Akeerthi4757@conestogac.on.ca
// import all the modules you need
const express = require('express');
const path = require('path');

// set up mongoose
const mongoose = require('mongoose');

// set up express-validator
const {check, validationResult} = require('express-validator');

// connect to DB
mongoose.connect('mongodb://localhost:27017/amorGiftStore',{
    useNewUrlParser: true,
    useUnifiedTopology: true
})

// define the model
const Order = mongoose.model('Order',{
    name : String,        
    email : String,
    phone : Number,
    address : String,
    city : String,
    province : String,
    country : String,
    postcode : String,
    keychains : Number,
    coffeemugs : Number,
    wristbands : Number,
    keychainsAmount : Number,
    coffeemugsAmount : Number,
    wristbandsAmount : Number,
    subTotal : Number,
    gst : Number,
    Total : Number
});

// set up the app
var myApp = express();

// set up the body-parser middleware
myApp.use(express.urlencoded({extended:false}));

// define/set the paths to public folder and views folder
myApp.set('view engine', 'ejs');
myApp.set('views', path.join(__dirname, 'views')); // set a value for express
myApp.use(express.static(__dirname + '/public')); // set up a middleware to server static files

// define the routes
// define the route for index page "/"
myApp.get('/',function(req, res){
    res.render('form');
});

// show all orders
myApp.get('/orders',function(req, res){
    // write some code to fetch all orders from db and send to the view orders
    Order.find({}).exec(function(errors, orders){
        console.log(errors);
        console.log(orders);
        res.render('orders', {orders:orders}); // will render views/orders.ejs
    });
});

// handle post
// we can fetch data from the request (req) using body parser
// body-parser is included with express now

myApp.post('/process', [
    // validations for all the input fields
    check('name', 'Name is required').notEmpty(),
    check('email', 'Email not in correct format').isEmail(),
    check('phone','Please enter Phone number as XXXXXXXXXX numbers only').matches(/^[0-9]{10}$/),
    check('address','Please enter your address.').notEmpty(),
    check('city', 'Please select a city from the list').notEmpty(),   
    check('province', 'Please select a province from the list').notEmpty(),
    check('country', 'Please enter your country').notEmpty(),
    check('postcode', 'Postcode not in correct format').matches(/^[A-Za-z][0-9][A-Za-z]\s[0-9][A-Za-z][0-9]$/),
], function(req, res){

    const errors = validationResult(req);
    console.log(errors);
    if(errors.isEmpty()){ // if no errors are there

        //fetch all the fields in the form
        var name = req.body.name;
        var email = req.body.email;
        var phone = req.body.phone; 
        var address = req.body.address;           
        var province = req.body.province;
        var city = req.body.city;
        var country = req.body.country;
        var postcode = req.body.postcode;
        var gst = req.body.gst;

        var keychains = req.body.keychains;
        var coffeemugs = req.body.coffeemugs;
        var wristbands = req.body.wristbands;

        var keychainsAmount = keychains * 15;
        var coffeemugsAmount = coffeemugs * 35;
        var wristbandsAmount = wristbands * 20;

        var subTotal = keychainsAmount + coffeemugsAmount + wristbandsAmount;

        //Using switch case statement for various province tax
        switch(province){
            case 'AB' :
                var gst   = subTotal * 0.05;
                break;
            case 'BC' :
                var gst   = subTotal * 0.11;
                break;
            case 'MB' :
                var gst   = subTotal * 0.05;
                break;
            case 'NB' :
                var gst   = subTotal * 0.15;
                break;
            case 'NFL' :
                var gst   = subTotal * 0.15;
                break;            
            case 'NT' :
                var gst   = subTotal * 0.05;
                break;
            case 'NS' :
                var gst   = subTotal * 0.15;
                break;
            case 'NVT' :
                var gst   = subTotal * 0.05;
                break;
            case 'ON' :
                var gst   = subTotal * 0.13;
                break;  
            case 'PEI' :
                var gst   = subTotal * 0.15;
                break;          
            case 'QC' :
                var gst   = subTotal * 0.05;
                break;                        
            case 'SK' :
                var gst   = subTotal * 0.05;
                break;
            case 'YN' :
                var gst   = subTotal * 0.05;
                break; 
        }
    // calculation of Total with subTotal and Tax of the respective province
    var Total = subTotal + gst;

    // prepare data to send to the view
    var pageData = {
        name : name,        
        email : email,
        phone : phone,
        address : address,
        city : city,
        province : province,
        country : country,
        postcode : postcode,
        keychains : keychains,
        coffeemugs : coffeemugs,
        wristbands : wristbands,
        keychainsAmount : keychainsAmount,
        coffeemugsAmount : coffeemugsAmount,
        wristbandsAmount : wristbandsAmount,
        subTotal : subTotal,
        gst : gst,
        Total : Total
    }
        // create an object for the model Order
        var myOrder = new Order(pageData);

        // save it to DB
        myOrder.save();

        // send the data to the view and render it
        res.render('receipt', pageData); // displaying the receipt
    }
    else{// When there are errors
        console.log(errors.array());
        res.render('form', {errors: errors.array()})
    }
});

// start the server (listen at a port)
myApp.listen(8080);
console.log('Everything executed, open http://localhost:8080/ in the browser.')